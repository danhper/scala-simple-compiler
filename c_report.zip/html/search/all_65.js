var searchData=
[
  ['empty_5fbuffer',['empty_buffer',['../file__reader_8c.html#a9061da1bbb3034f12943ca4f8d74b98c',1,'empty_buffer(void):&#160;file_reader.c'],['../file__reader_8h.html#a9061da1bbb3034f12943ca4f8d74b98c',1,'empty_buffer(void):&#160;file_reader.c']]]
];
