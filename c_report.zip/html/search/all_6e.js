var searchData=
[
  ['next',['next',['../structWord.html#a4eccd4f33b522ab43174f92041731543',1,'Word']]]
];
