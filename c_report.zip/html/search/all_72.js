var searchData=
[
  ['read_5ffile',['read_file',['../file__reader_8c.html#abc0054b274d9d15522bbf8d023c48313',1,'read_file(Hash *hash_table, const char *file_name):&#160;file_reader.c'],['../file__reader_8h.html#abc0054b274d9d15522bbf8d023c48313',1,'read_file(Hash *hash_table, const char *file_name):&#160;file_reader.c']]]
];
