var searchData=
[
  ['add_5fword',['add_word',['../list_8c.html#a92c781b7fb0ad5a66b2871da3cc5f17d',1,'add_word(Word **words, const char *word):&#160;list.c'],['../list_8h.html#a92c781b7fb0ad5a66b2871da3cc5f17d',1,'add_word(Word **words, const char *word):&#160;list.c']]]
];
