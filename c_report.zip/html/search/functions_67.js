var searchData=
[
  ['get_5fcount',['get_count',['../hash_8c.html#ab8229f95c27dcc14955c6d134200de14',1,'get_count(const Hash *hash_table, const char *word):&#160;hash.c'],['../hash_8h.html#ab8229f95c27dcc14955c6d134200de14',1,'get_count(const Hash *hash_table, const char *word):&#160;hash.c']]],
  ['get_5fnext_5fword',['get_next_word',['../file__reader_8c.html#a1cd1e5bbfab9a60e8a730383373cd953',1,'get_next_word(FILE *file, char *word):&#160;file_reader.c'],['../file__reader_8h.html#a1cd1e5bbfab9a60e8a730383373cd953',1,'get_next_word(FILE *file, char *word):&#160;file_reader.c']]]
];
