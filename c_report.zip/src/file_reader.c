/**
 * \file file_reader.c
 * \brief ファイルの読み込みに必要な関数の定義を持つファイル.
 * \date 2012年５月23日 
 */

#include <stdio.h>
#include "file_reader.h"
#include "hash.h"

/**
 * \fn void empty_buffer(void)
 * \brief バッファを空にするための関数.
 */
void empty_buffer(void)
{
  int c;
  while((c = getchar()) != '\n' && c != EOF);
}

/**
 * \fn int read_file(Hash* hash_table, const char* file_name)
 * \brief file_nameを読み込んでそれぞれの単語をhash_tableに代入する.
 * \param hash_table 代入するhash_table
 * \param file_name 読み込むファイル名.
 * \return 成功の場合1, 失敗の場合0.
 */
int read_file(Hash* hash_table, const char* file_name)
{
  FILE* file = fopen(file_name, "r");
  if(file == NULL)
  {
    return 0;
  }  
  while(1)
  {
    char word[100] = "";
    int reading = get_next_word(file, word);
    if(!reading)
    {
      break;
    }
    hash_insert(hash_table, word);
  }
  fclose(file);
  return 1;
}

/**
 * \fn int is_delimiter(char c)
 * \brief cが区切る文字であるかどうかを判定する.
 * \param c 判定したい文字.
 * \return 区切る文字の場合は1, それ以外は0.
 */
int is_delimiter(char c)
{
  return c == ' ' || c == ',' || c == '\n' || c == '\t' || c == '.' || c == '(' || c == ')';
}

/**
 * \fn int get_next_word(FILE* file, char* word)
 * \brief fileから読み込み次の単語をwordに代入する.
 * \param file 読み込むファイル.
 * \param word 代入するための文字列.
 * \return 成功の場合1, 失敗の場合0.
 */
int get_next_word(FILE* file, char* word)
{
  int c;
  while(is_delimiter((c = fgetc(file))));
  for(; c != EOF && !is_delimiter(c); c = fgetc(file))
  {
    *word++ = c;
  }
  return c != EOF;
}

