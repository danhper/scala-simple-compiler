/**
 * \file file_reader.h
 * \brief ファイルの読み込みに必要な関数の宣言を持つファイル.
 * \date 2012年５月23日  
 */

#ifndef FILE_READER_H_
#define FILE_READER_H_

#include "hash.h"

int get_next_word(FILE* file, char* word);
void empty_buffer(void);
int read_file(Hash* hash_table, const char* file_name);
int is_delimiter(char c);

#endif /* FILE_READER_H_ */
