/**
 * \file hash.c
 * \brief ハッシュ構造に必要な関数を定義しているファイル
 * \date 2012年５月23日  
 */

#include <stdlib.h>
#include <stdio.h>

#include "hash.h"
#include "list.h"

/**
 * \fn void hash_insert(const Hash* hash_table, const char* word)
 * \brief wordをhash_tableに代入する関数.
 * \param hash_table 文字列を確保するためのハッシュテーブル.
 * \param word 代入する文字列.
 */

void hash_insert(const Hash* hash_table, const char* word)
{
  unsigned int index = hash(word, hash_table->size);
  if(index >= hash_table->size)
  {
    return;
  }
  else
  {
    add_word(&hash_table->words[index], word);
  }
}

/**
 * \fn Hash* init_hash(unsigned int size)
 * \brief sizeで新しいハッシュテーブルを初期化する.
 * \param size 初期化したいハッシュテーブルの大きさ.
 * \return 初期化されたハッシュテーブル.
 */
Hash* init_hash(unsigned int size)
{
  unsigned int i;
  Hash* hash_table = malloc(sizeof(Hash));
  hash_table->words = malloc(size * sizeof *hash_table->words);
  hash_table->size = size;
  for(i = 0; i < hash_table->size; i++)
  {
    hash_table->words[i] = NULL;
  }
  return hash_table;
}

/**
 * \fn unsigned int hash(const char *word, int size)
 * \brief wordをsizeを用いてハッシュ化する.
 * \param word ハッシュ化する文字列.
 * \param size ハッシュテーブルの大きさ.
 * \return ハッシュ化の結果.
 */
unsigned int hash(const char *word, int size)
{
  unsigned int h = 0;
  for(; *word; word++)
    h = *word + h * 31;
  return h % size;
}

/**
 * \fn Word* hash_get_word(const Hash* hash_table, const char* word)
 * \brief hash_tableからwordを持っているWordへのポインタ構造体を返す.
 * \param hash_tableしたいハッシュテーブル.
 * \param word 探索する文字列.
 * \return wordを持ったWord構造体へのポインタ. 失敗の場合NULLを返す.
 */
Word* hash_get_word(const Hash* hash_table, const char* word)
{
  Word* words = hash_get_array(hash_table, word);
  return list_get(words, word);
}

/**
 * \fn Word* hash_get_array(const Hash* hash_table, const char* word)
 * \brief hash_tableからwordの入っているリストへのポインタを返す. wordがリストの先頭の要素の場合はhash_get_wordと同じ値を返すことになる.
 * \param hash_tableしたいハッシュテーブル.
 * \param word 探索する文字列.
 * \return wordを持ったリスト. 失敗の場合はNULLを返す.
 */
Word* hash_get_array(const Hash* hash_table, const char* word)
{
  unsigned int index;
  Word* words;
  if(!hash_has(hash_table, word))
  {
    return NULL;
  }
  index = hash(word, hash_table->size);
  words = hash_table->words[index];
  return words;
}

/**
 * \fn int hash_has(const Hash* hash_table, const char* word)
 * \brief wordがハッシュテーブルに存在しうるかどうかを確かめる. 
 * \param hash_tableしたいハッシュテーブル.
 * \param word 探索する文字列.
 * \return 存在しない場合は0, 存在しうる場合は1を返す.
 */
int hash_has(const Hash* hash_table, const char* word)
{
  unsigned int index = hash(word, hash_table->size);
  Word* words = NULL;
  if(index >= hash_table->size)
  {
    return 0;
  }
  words = hash_table->words[index];
  if(words == NULL)
  {
    return 0;
  }
  return 1;  
}


/**
 * \fn void show_hash(const Hash* hash_table)
 * \brief ハッシュの傾きを出力する.
 * \param hash_table 傾き表示したいハッシュテーブル.
 */
void show_hash(const Hash* hash_table)
{
  unsigned int i;
  for(i = 0; i < hash_table->size; i++)
  {
    printf("[%d]:%d\n", i, list_length(hash_table->words[i]));
  }
}


/**
 * \fn int get_count(const Hash* hash_table, const char* word)
 * \brief hash_tableにwordの出現回数.
 * \param hash_table ハッシュテーブル.
 * \param word 探索する文字列.
 * \return wordの出現回数.
 */
int get_count(const Hash* hash_table, const char* word)
{
  Word* word_struct = hash_get_word(hash_table, word);
  if(word_struct == NULL)
  {
    return 0;
  }
  else
  {
    return word_struct->count;
  }  
}

/**
 * \fn void free_hash(Hash* hash_table)
 * \brief ハッシュテーブルのメモリを解放する.
 * \param hash_table 解放するハッシュテーブル.
 */
void free_hash(Hash* hash_table)
{
  unsigned int i;
  for(i = 0; i < hash_table->size; i++)
  {
    free_list(hash_table->words[i]);
  }
  free(hash_table->words);
  free(hash_table);
}
