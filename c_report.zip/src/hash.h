/**
 * \file hash.h
 * \brief ハッシュテーブルに使う構造体と必要な関数の宣言.
 * \date 2012年５月23日  
 */
#ifndef HASH_H_
#define HASH_H_

#include "list.h"

/**
 * \struct Hash
 * \brief ハッシュテーブルを表す構造体.
 */
typedef struct
{
  Word** words; /*!< 文字列を持つリストへのポインタの配列. */
  unsigned int size; /*!< ハッシュのサイズ. */
} Hash;


void hash_insert(const Hash* hash_table, const char* word);
Hash* init_hash(unsigned int size);
unsigned int hash(const char* word, int size);
Word* hash_get_array(const Hash* hash_table, const char* word);
Word* hash_get_word(const Hash* hash_table, const char* word);
int hash_has(const Hash* hash_table, const char* word);
void show_hash(const Hash* hash_table);
int get_count(const Hash* hash_table, const char* word);
void free_hash(Hash* hash_table);

#endif /* HASH_H_ */
