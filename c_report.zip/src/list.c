/**
 * \file list.c
 * \brief リスト構造に必要な関数を定義しているファイル
 * \date 2012年５月23日  
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "list.h"

static Word* make_word(const char* word);

/**
 * \fn Word* list_get(Word* words, const char *word)
 * \brief wordsからwordを探索し, wordを持ったノード結果を返す.
 * \param words リストのノードへのポインタ.
 * \param word 探索する文字列.
 * \return wordを持ったノード. 失敗の場合はNULLを返す.
 */
Word* list_get(Word* words, const char *word)
{
  Word* tmp = words;
  while(tmp != NULL)
  {
    if(strcmp(tmp->word, word) == 0)
    {
      return tmp;
    }
    tmp = tmp->next;
  }
  return NULL;
}

/**
 * \fn void add_word(Word** words, const char* word)
 * \brief wordsにwordを追加する. wordが既に存在している場合はwordを持ったノードのcountをインクリメントする
 * \param words リスト構造のポインタへのポインタ. 二重ポインタはwordsがNULLの時に変化できるように使う.
 * \param word 追加したい文字列.
 */
void add_word(Word** words, const char* word)
{
  Word* new_word = NULL;
  Word* tmp = NULL;

  if(*words == NULL)
  {
    new_word = make_word(word);
    *words = new_word;
  }
  else
  {
    Word* last = NULL;
    for(tmp = *words; tmp != NULL; last = tmp, tmp = tmp->next)
    {
      if(strcmp(tmp->word, word) == 0)
      {
        tmp->count++;
        return;
      }
    }
    new_word = make_word(word);
    last->next = new_word;
  }
}

/**
 * \fn int list_length(const Word* words)
 * \brief wordsの長さを求める.
 * \param words リストへのポインタ
 * \return wordsの長さ.
 */
int list_length(const Word* words)
{
  int count = 0;
  for(; words != NULL; count++, words = words->next);
  return count;
}

/**
 * \fn static Word* make_word(const char* word)
 * \brief リストの１つのノードをwordで初期化して返す.
 * \param ノードの初期化で用いる文字列.
 * \return 初期化されたノード.
 */
static Word* make_word(const char* word)
{
  Word* new_word = malloc(sizeof(Word));
  unsigned int length = strlen(word);
  new_word->word = malloc(length + 1);
  new_word->count = 1;
  strcpy(new_word->word, word);
  new_word->next = NULL;
  return new_word;
}

/**
 * \fn void free_list(Word* words)
 * \brief wordsで使ったメモリーを解放する.
 * \param words 解放するリスト.
 */
void free_list(Word* words)
{
  Word* tmp = words;
  while(tmp != NULL)
  {
    Word* to_free = tmp;
    tmp = tmp->next;
    free(to_free->word);
    free(to_free);
  }
}
