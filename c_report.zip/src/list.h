/**
 * \file list.h
 * \brief リストに使う構造体と必要な関数の宣言.
 * \date 2012年５月23日  
 */
#ifndef LIST_H_
#define LIST_H_

typedef struct Word Word;

/**
 * \struct Word
 * \brief 文字列を持つリスト構造.
 */
struct Word
{
  char* word; /*!< 単語を表している文字列. */
  int count; /*!< 文字列(単語)の出現回数. */
  Word* next; /*!< リストの次の要素. */
};

Word* list_get(Word* words, const char *word);
void add_word(Word** words, const char* word);
int list_length(const Word* words);
void free_list(Word* words);

#endif /* LIST_H_ */
