/**
 * \file main.c
 * \brief main関数を持つファイル.
 * \date 2012年５月23日  
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hash.h"
#include "list.h"
#include "file_reader.h"


void prompt_word(const Hash* hash_table);

/**
 * \fn int main(int argc, char* argv[])
 * \brief プログラムの引数を確かめた上それぞれの関数を呼び出すことによってファイルを読み込み, 標準入力待ち状態に入る.
 * \param argc 引数の数. このプログラムの場合は3でなければならない.
 * \param argv それぞれの引数. ２つ目の引数はハッシュのサイズ. ３つ目の引数はファイル名.
 * \return 正常終了したかどうかを表す整数.
 */
int main(int argc, char* argv[])
{
  int hash_size;
  Hash* hash_table = NULL;

  if(argc != 3 || (hash_size = atoi(argv[1])) <= 0) 
  {
    printf("Usage : ./wordcount hash_size (>0) file_name\n");
    exit(EXIT_FAILURE);
  }
  hash_table = init_hash(hash_size);
  if(!read_file(hash_table, argv[2]))
  {
    printf("File %s could not be opened.\n", argv[2]);
    exit(EXIT_FAILURE);
  }
  show_hash(hash_table);
  prompt_word(hash_table);

  free_hash(hash_table);
  
  return EXIT_SUCCESS;
}

/**
 * \fn void prompt_word(const Hash* hash_table)
 * \brief 標準入力から単語を読み込み, 成功した場合はその単語のハッシュテーブルでの出現回数を出力する.
 * \param hash_table 単語を持っているハッシュテーブル.
 */
void prompt_word(const Hash* hash_table)
{
  char word[100];
  while(1)
  {
    int scanf_ret;
    printf("Word => ");
    scanf_ret = scanf("%s", word);
    if(scanf_ret == EOF || strcmp(word, "0") == 0)
    {
      break;
    }
    printf("%s: %d\n", word, get_count(hash_table, word));
    empty_buffer();
  }
}


